
<center><h3>
<hr />
<p>
<a href="update.php">Edit User</a>&nbsp
<a href="delete.php">Delete User</a>&nbsp
<a href="search.php">Search User</a>
</center></h3>
<hr />