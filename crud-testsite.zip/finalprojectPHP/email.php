

<html>

<head>
</head>


<body>
<h3>Send email to:<?php echo " ".$_REQUEST['email'];?></h3>
<?php

$date=date("d -m -y");
echo "<p>Date: ".$date;







?>
</body>
</html>